config = {
    "elastic_cache_url":
    "url-resource-cluster.yaeyym.cfg.use2.cache.amazonaws.com"
}
