config = {
    "elastic_cache_url":
    "prod-url-resource-cluster.yaeyym.cfg.use2.cache.amazonaws.com"
}
